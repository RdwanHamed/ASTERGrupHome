<?php
/**
 * PHPMailer Configuration for Gmail SMTP
 * 
 * IMPORTANT: To use Gmail SMTP, you need to:
 * 1. Enable 2-Step Verification on your Gmail account
 * 2. Generate an App Password: https://myaccount.google.com/apppasswords
 * 3. Use that App Password (not your regular Gmail password) below
 */

// Gmail SMTP Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'wiruqoleqec072@gmail.com'); // Your Gmail address
define('SMTP_PASSWORD', ''); // PUT YOUR GMAIL APP PASSWORD HERE (16 characters)
define('SMTP_FROM_EMAIL', 'wiruqoleqec072@gmail.com');
define('SMTP_FROM_NAME', 'Aster Group Home');

// Enable SMTP debugging (set to 0 for production)
define('SMTP_DEBUG', 0);
?>






