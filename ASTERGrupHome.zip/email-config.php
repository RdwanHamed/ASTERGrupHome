<?php
/**
 * Email Configuration for Admission Form
 * 
 * TO ENABLE EMAIL SENDING:
 * 1. Enable 2-Step Verification on your Gmail account
 * 2. Generate an App Password: https://myaccount.google.com/apppasswords
 * 3. Paste the 16-character App Password below (not your regular Gmail password)
 * 4. Save this file
 */

// Recipient email (where form submissions will be sent)
define('RECIPIENT_EMAIL', 'wiruqoleqec072@gmail.com');

// Gmail SMTP Configuration (for sending emails)
define('SMTP_ENABLED', true);
define('SMTP_USERNAME', 'wiruqoleqec072@gmail.com');
define('SMTP_PASSWORD', 'RDWAN12345678901');
define('SMTP_FROM_EMAIL', 'wiruqoleqec072@gmail.com');
define('SMTP_FROM_NAME', 'Aster Group Home');





